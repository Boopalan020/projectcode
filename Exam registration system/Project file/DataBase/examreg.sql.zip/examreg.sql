-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 28, 2019 at 04:23 PM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `examreg`
--

-- --------------------------------------------------------

--
-- Table structure for table `address`
--

DROP TABLE IF EXISTS `address`;
CREATE TABLE IF NOT EXISTS `address` (
  `door` varchar(7) NOT NULL,
  `taluk` varchar(20) NOT NULL,
  `city` varchar(20) NOT NULL,
  `pincode` varchar(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `address`
--

INSERT INTO `address` (`door`, `taluk`, `city`, `pincode`) VALUES
('3/355', 'Sankagiri', 'Salem', '637301'),
('4r/56', 'Perundurai', 'Erode', '638052'),
('79/3,PW', 'Paramathi-Velur', 'Namakkal', '637207');

-- --------------------------------------------------------

--
-- Table structure for table `hscdet`
--

DROP TABLE IF EXISTS `hscdet`;
CREATE TABLE IF NOT EXISTS `hscdet` (
  `certificate_no` int(12) NOT NULL,
  `school_name` varchar(30) NOT NULL,
  `boards_name` varchar(10) NOT NULL,
  `marks` double(6,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hscdet`
--

INSERT INTO `hscdet` (`certificate_no`, `school_name`, `boards_name`, `marks`) VALUES
(45239587, 'govt school', 'Matric', 97.00),
(29068196, 'Kurunji Matric hr sec school', 'None', 97.00),
(21332345, 'Malar', 'None', 94.00);

-- --------------------------------------------------------

--
-- Table structure for table `particulars`
--

DROP TABLE IF EXISTS `particulars`;
CREATE TABLE IF NOT EXISTS `particulars` (
  `Examination` varchar(80) NOT NULL,
  `dist` varchar(20) NOT NULL,
  `centre` varchar(30) NOT NULL,
  `totalfee` varchar(5) NOT NULL,
  `feestatus` varchar(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `particulars`
--

INSERT INTO `particulars` (`Examination`, `dist`, `centre`, `totalfee`, `feestatus`) VALUES
('GROUP I SERVICES EXAMINATION (001)', 'Namakkal', 'Malar School', '1500', 'Paid'),
('GROUP I SERVICES EXAMINATION (001)', 'Namakkal', 'Thiruchengodu Govt School', '1500', 'Paid'),
('GROUP I SERVICES EXAMINATION (001)', 'Namakkal', 'Namakkal', '1500', 'Paid'),
('GROUP I SERVICES EXAMINATION (001)', 'salem', 'salem', '1500', 'Paid');

-- --------------------------------------------------------

--
-- Table structure for table `perdet`
--

DROP TABLE IF EXISTS `perdet`;
CREATE TABLE IF NOT EXISTS `perdet` (
  `name` varchar(30) NOT NULL,
  `father` varchar(30) NOT NULL,
  `mother` varchar(30) NOT NULL,
  `gender` varchar(6) NOT NULL,
  `dob` date NOT NULL,
  `phone` varchar(10) NOT NULL,
  `district` varchar(30) NOT NULL,
  `state` varchar(20) NOT NULL,
  `religion` varchar(15) NOT NULL,
  `nationality` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `perdet`
--

INSERT INTO `perdet` (`name`, `father`, `mother`, `gender`, `dob`, `phone`, `district`, `state`, `religion`, `nationality`) VALUES
('Boopalan', 'Magudeswaran', 'Umamaheswari', 'Male', '2000-02-20', '8825971005', 'Salem', 'None', 'Hindu', 'Indian'),
('KHariprakash', 'Karthikeyan', 'Geetha', 'Male', '1999-11-10', '8825971005', 'Namakkal', 'TamilNadu', 'Hindu', 'Indian'),
('Dhivakar', 'Suresh', 'Lakshmi', 'Male', '2000-07-19', '9487653097', 'Chennai', 'TamilNadu', 'Hindu', 'Indian'),
('Gibson', 'Loganathan', 'Joysmary', 'Male', '1999-06-06', '9822056789', 'Chennai', 'TamilNadu', 'Hindu', 'Indian'),
('HariprakashK', 'KarthikeyanD', 'GeethaR', 'Male', '1999-11-10', '9944957231', 'Namakkal', 'TamilNadu', 'Hindu', 'Indian'),
('HariprakashK', 'KarthikeyanD', 'GeethaR', 'Male', '1999-11-10', '9944957231', 'Namakkal', 'TamilNadu', 'Hindu', 'Indian'),
('hari', 'karthick', 'geetha', 'Male', '2019-08-15', '1234567890', 'Erode', 'TamilNadu', 'Hindu', 'Indian');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

DROP TABLE IF EXISTS `register`;
CREATE TABLE IF NOT EXISTS `register` (
  `Userid` varchar(20) NOT NULL,
  `email` varchar(35) NOT NULL,
  `mobile` varchar(10) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`Userid`, `email`, `mobile`, `password`) VALUES
('hariprakash123', 'hari@gmail.com', '9089127890', 'hari@1234'),
('2021', 'magudeswaran8098@gmail.com', '8825971005', 'palan@1234'),
('Hari_Spidey', 'hari10nov99@gmail.com', '9944957231', 'Hari@123');

-- --------------------------------------------------------

--
-- Table structure for table `sslcdet`
--

DROP TABLE IF EXISTS `sslcdet`;
CREATE TABLE IF NOT EXISTS `sslcdet` (
  `certno` varchar(8) NOT NULL,
  `schl_name` varchar(50) NOT NULL,
  `boards` varchar(10) NOT NULL,
  `marks` double(6,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sslcdet`
--

INSERT INTO `sslcdet` (`certno`, `schl_name`, `boards`, `marks`) VALUES
('47893908', 'Malar Matric School', 'Matric', 93.20),
('83670174', 'Govt Hr Sec School', 'State Boar', 88.90),
('43680788', 'Vidhyalakshmi', 'Matric', 97.00);
